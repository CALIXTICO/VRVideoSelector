using System;
using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Networking;
using UnityEngine.UI;
using TMPro;

public class VideoTile : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [Header("UI Refs")]
    [SerializeField] private RawImage thumbnail;         // RawImage para la miniatura
    [SerializeField] private Image progress;             // Image Filled (Radial 360)
    [SerializeField] private TextMeshProUGUI title;      // Título

    [Header("Gaze Timing (seconds)")]
    [SerializeField, Tooltip("Tiempo mirando antes de mostrar la rueda")]
    private float preHoldTime = 2f;
    [SerializeField, Tooltip("Tiempo que tarda en llenarse la rueda")]
    private float fillTime = 3f;

    [Header("Placeholder (opcional)")]
    [SerializeField, Tooltip("Textura antes de que cargue la miniatura")]
    private Texture2D placeholderTexture;

    private VideoItem _item;
    private Action<VideoItem> _onSelected;
    private Coroutine _gazeRoutine;

    public void Setup(VideoItem item, Action<VideoItem> onSelected)
    {
        _item = item;
        _onSelected = onSelected;

        // Título
        if (title) title.text = item?.Title ?? string.Empty;

        // Progreso (inicia oculto)
        if (progress)
        {
            progress.type = Image.Type.Filled;
            progress.fillMethod = Image.FillMethod.Radial360;
            progress.fillOrigin = (int)Image.Origin360.Top;
            progress.fillAmount = 0f;
            progress.enabled = false;
        }

        // Asegurar layout seguro del tile y capas de dibujo
        ApplySafeLayout();

        // Placeholder visible de inmediato
        if (thumbnail)
        {
            if (placeholderTexture) thumbnail.texture = placeholderTexture;
            thumbnail.enabled = true;
        }

        // Cargar miniatura con fallbacks (maxres/hq/sd/mq/default)
        if (!string.IsNullOrEmpty(item?.YoutubeId))
        {
            StartCoroutine(LoadThumbnailWithFallbacks(item.YoutubeId));
        }
        else
        {
            Debug.LogWarning("[VideoTile] YoutubeId vacío.");
        }
    }

    // ========= Gaze API (por ahora funciona con mouse hover; luego conectamos raycaster de mirada) =========
    public void BeginGaze()
    {
        if (_gazeRoutine != null) StopCoroutine(_gazeRoutine);
        _gazeRoutine = StartCoroutine(GazeSelectRoutine());
    }

    public void EndGaze()
    {
        if (_gazeRoutine != null) StopCoroutine(_gazeRoutine);
        _gazeRoutine = null;
        if (progress) { progress.fillAmount = 0f; progress.enabled = false; }
    }

    public void OnPointerEnter(PointerEventData eventData) => BeginGaze();
    public void OnPointerExit(PointerEventData eventData)  => EndGaze();

    private void OnDisable()
    {
        if (_gazeRoutine != null)
        {
            StopCoroutine(_gazeRoutine);
            _gazeRoutine = null;
        }
        if (progress) { progress.fillAmount = 0f; progress.enabled = false; }
    }

    // ========= Internos =========

    private void ApplySafeLayout()
    {
        // El root del prefab debe tener RectTransform y (opcional) un Image como fondo
        var rootRT = transform as RectTransform;
        if (rootRT != null)
        {
            rootRT.localScale = Vector3.one;                 // nada de 0.01
            rootRT.localRotation = Quaternion.identity;
        }

        // Forzar que el THUMBNAIL ocupe toda la celda (stretch con offsets 0)
        if (thumbnail)
        {
            var rt = thumbnail.rectTransform;
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
            thumbnail.color = Color.white;       // alpha 255
            thumbnail.maskable = true;

            // Orden de dibujo: Background (si existe) debajo, luego THUMBNAIL, luego Progress/Title
            thumbnail.transform.SetAsFirstSibling();
        }

        if (progress) progress.transform.SetAsLastSibling();
        if (title)    title.transform.SetAsLastSibling();

        // Por si algún padre tuviera CanvasGroup con alpha 0 (raro pero pasa)
        var cg = GetComponent<CanvasGroup>();
        if (cg) cg.alpha = 1f;
    }

    private IEnumerator LoadThumbnailWithFallbacks(string youtubeId)
    {
        string Url(string q) => $"https://img.youtube.com/vi/{youtubeId}/{q}.jpg";
        var urls = new string[]
        {
            Url("maxresdefault"),
            Url("hqdefault"),
            Url("sddefault"),
            Url("mqdefault"),
            Url("default")
        };

        Texture2D tex = null;
        foreach (var u in urls)
        {
            using (var req = UnityWebRequestTexture.GetTexture(u))
            {
                yield return req.SendWebRequest();
#if UNITY_2020_1_OR_NEWER
                if (req.result == UnityWebRequest.Result.Success)
#else
                if (!req.isNetworkError && !req.isHttpError)
#endif
                {
                    tex = DownloadHandlerTexture.GetContent(req);
                    Debug.Log($"[VideoTile] Thumbnail OK: {u} ({tex.width}x{tex.height})");
                    break;
                }
                else
                {
                    Debug.LogWarning($"[VideoTile] Thumbnail intento fallido: {u} -> {req.error}");
                }
            }
        }

        if (tex != null && thumbnail)
        {
            thumbnail.texture = tex;
            thumbnail.enabled = true;

            // Reasegura orden (por si el prefab se reordenó)
            thumbnail.transform.SetAsFirstSibling();
            if (progress) progress.transform.SetAsLastSibling();
            if (title)    title.transform.SetAsLastSibling();
        }
    }

    private IEnumerator GazeSelectRoutine()
    {
        float t = 0f;
        if (progress) { progress.fillAmount = 0f; progress.enabled = false; }

        while (t < preHoldTime)
        {
            t += Time.unscaledDeltaTime;
            yield return null;
        }

        if (progress) { progress.enabled = true; progress.fillAmount = 0f; }

        float p = 0f;
        while (p < 1f)
        {
            p += Time.unscaledDeltaTime / Mathf.Max(0.001f, fillTime);
            if (progress) progress.fillAmount = Mathf.Clamp01(p);
            yield return null;
        }

        _onSelected?.Invoke(_item);
    }
}

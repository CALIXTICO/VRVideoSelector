using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[DefaultExecutionOrder(100)]
public class EyeGazeUIRaycaster : MonoBehaviour
{
    [Header("Refs")]
    [SerializeField] private EyeGazeProvider gazeProvider;     // arrástralo
    [SerializeField] private Canvas worldCanvas;               // Canvas en World Space
    [SerializeField] private GraphicRaycaster uiRaycaster;     // del Canvas
    [SerializeField] private Camera eventCamera;               // XR/Main Camera

    [Header("Ray settings")]
    [SerializeField] private float maxDistance = 12f;
    [SerializeField] private LayerMask physicsMask = ~0;       // fallback con colliders
    [SerializeField] private bool logHits = true;
    [SerializeField] private bool drawGizmoRay = true;

    private PointerEventData _ped;
    private GameObject _currentOverGO;
    private readonly List<RaycastResult> _results = new();
    private Plane _canvasPlane;
    private GazeReticleUI _reticleUI;
    private RectTransform _canvasRT;

    void Awake()
    {
        if (!eventCamera) eventCamera = Camera.main;
        if (!gazeProvider) gazeProvider = FindFirstObjectByType<EyeGazeProvider>();
        if (!worldCanvas) worldCanvas = FindFirstObjectByType<Canvas>();
        if (!uiRaycaster && worldCanvas) uiRaycaster = worldCanvas.GetComponent<GraphicRaycaster>();

        if (!EventSystem.current)
        {
            var go = new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
            Debug.LogWarning("[GazeUI] No había EventSystem. Se creó uno.");
        }

        _ped = new PointerEventData(EventSystem.current);
        _canvasRT = worldCanvas ? worldCanvas.GetComponent<RectTransform>() : null;
        _canvasPlane = (worldCanvas)
            ? new Plane(worldCanvas.transform.forward, worldCanvas.transform.position)
            : new Plane(Vector3.forward, 0f);

        // Retícula:
        _reticleUI = GetComponentInChildren<GazeReticleUI>(true);
        if (!_reticleUI && worldCanvas)
        {
            var holder = worldCanvas.GetComponentInChildren<GazeReticleUI>(true);
            if (holder) _reticleUI = holder;
            else
            {
                _reticleUI = worldCanvas.gameObject.AddComponent<GazeReticleUI>();
            }
        }
        if (_reticleUI != null && _canvasRT != null)
            _reticleUI.Ensure(_canvasRT);
    }

    void Update()
    {
        if (!TryGetRay(out var ray))
        {
            LogHit("(none)");
            if (_reticleUI) _reticleUI.Show(false);
            HandleEnterExit(null);
            return;
        }

        if (drawGizmoRay) Debug.DrawRay(ray.origin, ray.direction * maxDistance, Color.cyan);

        // === 1) Ray ↔ Plano del Canvas para obtener screenPos: ===
        if (!_canvasPlane.Raycast(ray, out var t) || t <= 0f || t > maxDistance)
        {
            HandleEnterExit(null);
            if (_reticleUI) _reticleUI.Show(false);
            LogHit("(none)");
            return;
        }

        var worldPoint = ray.origin + ray.direction * t;
        var screenPos  = eventCamera.WorldToScreenPoint(worldPoint);

        if (_reticleUI)
        {
            _reticleUI.Show(true);
            _reticleUI.SetScreenPos(screenPos, eventCamera);
        }

        // === 2) UI Raycast (preferimos RaycastAll para incluir todos los GraphicRaycaster activos) ===
        _ped.Reset();
        _ped.position = screenPos;
        _results.Clear();
        EventSystem.current.RaycastAll(_ped, _results);

        if (_results.Count > 0)
        {
            var rr = _results[0];
            var overGO = rr.gameObject;

            // Informamos correctamente el raycast actual (ayuda a algunos handlers):
            _ped.pointerCurrentRaycast = rr;

            // Disparamos enter/exit para que tus IPointerEnter/Exit (GazeHighlight) reaccionen:
            HandleEnterExit(overGO);

            LogHit(overGO ? overGO.name : "(none)");
            return;
        }

        // === 3) Fallback Physics (si añadiste colliders a los tiles) ===
        if (Physics.Raycast(ray, out var phit, maxDistance, physicsMask, QueryTriggerInteraction.Collide))
        {
            var go = phit.collider.gameObject;
            HandleEnterExit(go);
            LogHit(go.name);
            return;
        }

        // Nada
        HandleEnterExit(null);
        LogHit("(none)");
    }

    bool TryGetRay(out Ray ray)
    {
        ray = default;
        if (!gazeProvider) return false;
        return gazeProvider.TryGetEyeGazeRay(out ray);
    }

    void HandleEnterExit(GameObject newOver)
    {
        if (_currentOverGO == newOver) return;

        // EXIT del anterior
        if (_currentOverGO)
            ExecuteEvents.ExecuteHierarchy(_currentOverGO, _ped, ExecuteEvents.pointerExitHandler);

        _currentOverGO = newOver;

        // ENTER del nuevo
        if (_currentOverGO)
            ExecuteEvents.ExecuteHierarchy(_currentOverGO, _ped, ExecuteEvents.pointerEnterHandler);
    }

    void LogHit(string name)
    {
        if (logHits) Debug.Log($"[GazeUI] Hit: {name}");
    }

    public void RebuildCanvasPlane()
    {
        if (worldCanvas)
            _canvasPlane = new Plane(worldCanvas.transform.forward, worldCanvas.transform.position);
    }

    void OnDrawGizmos()
    {
        if (!drawGizmoRay) return;
        if (!gazeProvider) return;
        if (gazeProvider.TryGetEyeGazeRay(out var ray))
        {
            Gizmos.color = Color.cyan;
            Gizmos.DrawRay(ray.origin, ray.direction * maxDistance);
        }
    }
}
